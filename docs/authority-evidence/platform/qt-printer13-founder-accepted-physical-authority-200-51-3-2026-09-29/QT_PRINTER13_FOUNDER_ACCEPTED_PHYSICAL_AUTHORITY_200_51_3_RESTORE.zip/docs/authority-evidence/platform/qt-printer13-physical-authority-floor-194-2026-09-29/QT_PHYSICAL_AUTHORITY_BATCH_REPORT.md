# QT Printer #13 — Physical Authority Completion Pass

Date: 2026-09-28  
Starting/current Git HEAD: `309d3bb5e3f65c2454b77f7489274bfeb2ac1236`  
Founder acceptance: **PENDING**

## Governing gate retained

`EXACT FACE + PUBLISHER EXTENT → PHYSICAL TARGET PLANE → TARGET-SPECIFIC UGO → ADVERSARIAL VERIFY → BACKEND → LIFECYCLE`

No family geometry, Leg Three template, unscaled pixel geometry, shared runtime redesign, RESULT/SEC/Vault/USM change, commit, push, or deploy was used.

## Final 254-target census

| Classification | Count |
|---|---:|
| PASS | 0 |
| REPAIR→PASS | 194 |
| HOLD | 9 |
| N/A | 51 |
| **TOTAL** | **254** |

`PASS` remains zero because every admitted geometry-bearing QT surface replaced contaminated or unproven authority during this batch. `N/A` means the current truthful capability requires no hit-region geometry.

## Exact-face completion pass

The compiler now reads each exact registered face at its publisher physical extent, resolves strong closed physical boundaries from that face, converts them to target-plane inches and normalized UGO, and rejects ambiguous classification before admission. Quarantined Leg Three coordinates may distinguish semantic correspondence only; no quarantined coordinate is emitted as physical or runtime authority.

## Exact-target extraction used

Implemented once and batch-applied:

1. strict target-specific nested/concentric boundary extraction;
2. repeated closed-object and color-separated object extraction;
3. primary exact-figure extraction;
4. outer-figure plus internal-region extraction;
5. ordered and positioned object extraction;
6. three-tone physical-region extraction;
7. faint exact-line recovery; and
8. false-positive rejection for tiny marks, logos, duplicate outline edges, page-scale contours, ambiguous candidate groups, and multi-chain topologies.

The compiler remains `docs/backend/build_qt_physical_authority_batch.py`; exact-face extraction is owned by `docs/backend/qt_physical_boundary_extractor.py`.

## Admitted targets (194)

Every admission has its own exact-face physical-source artifact, edge proof, adversarial boundary challenges, candidate contract, and Backend admission record in [`QT_PHYSICAL_AUTHORITY_BATCH_MANIFEST.json`](QT_PHYSICAL_AUTHORITY_BATCH_MANIFEST.json). No admitted target borrows another target's geometry. The manifest is the exact 194-target inventory.

## Remaining HOLDs

All 9 remaining HOLDs are listed target-by-target in the manifest with the exact blocker:

- `B-27-P1`: faint printed ring 7 remains physically ambiguous;
- `CR-202`: physical-to-runtime boundary projection contradiction;
- `DART BOARD`: physical-to-runtime boundary projection contradiction;
- `DEA-Q-RL`: target-field boundary remains physically ambiguous;
- `HOSTAGE-2`: the overlapping right-figure boundary remains physically ambiguous;
- `HOSTAGE-3`: the overlapping right-figure boundary cannot be isolated from the exact face;
- `LA-P1`: the lower named region remains physically ambiguous;
- `NM-DPS-Q3`: physical-to-runtime boundary projection contradiction; and
- `SHOOTIN ACES`: physical-to-runtime boundary projection contradiction across overlapping card objects.

The former missing-sheet-extent holds (`DSQ-M4-100R`, `DSQ-M4-50R`) were resolved from preserved publisher catalog evidence and admitted. These nine remain held rather than converting ambiguous or occluded artwork into authority.

## Backend and lifecycle verification

- Active class-generated QT geometry: **0**.
- All contracts resolve uniquely with **0 duplicate identities**.
- Active QT contract files: **244** (50 non-geometry/evidence roads plus 194 physically admitted target-scoring roads; one contract covers the paired surface identity reflected by the 254-surface census).
- All 194 admitted targets passed `TARGET → RESULT → SEC → VAULT → exact reopen`.
- All 194 preserved canonical UGO observations unchanged through exact reopen.
- Every lifecycle observation reconciled exactly once.

Evidence: [`QT_PHYSICAL_AUTHORITY_LIFECYCLE_VERIFICATION.json`](QT_PHYSICAL_AUTHORITY_LIFECYCLE_VERIFICATION.json).

Regression results:

- QT physical-authority admission guards: PASS;
- displaced-boundary negative control: PASS;
- declarative target-scoring shared road: PASS;
- target execution scale architecture: PASS;
- contract identity/target-mission uniqueness: PASS.

## Status

The full 254-target exact-face pass is complete. 194 target-specific physical UGOs are admitted, 51 targets remain truthfully geometry-N/A, and 9 remain safely held with exact target-level reasons. The authority model was not changed.

No commit, push, or deploy was performed.
