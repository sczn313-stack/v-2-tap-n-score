# QT Extractor Expansion Result

Initial extractor backlog: **181**
Admitted from that backlog: **10**
Converted from generic backlog to a concrete target gate blocker: **145**
Still requiring a specialized reusable extractor: **26**

| Cluster | Original | Admitted | Concrete blocker | Extractor still unsupported |
|---|---:|---:|---:|---:|
| SILHOUETTE_SPATIAL_ZONES | 60 | 2 | 58 | 0 |
| NESTED_SCORING_OR_CONCENTRIC_REGIONS | 53 | 4 | 38 | 11 |
| MULTI_FIGURE_AND_RELATIONSHIP_OBJECTS | 29 | 1 | 27 | 1 |
| REPEATED_DISCRETE_DISCRIMINATION_OBJECTS | 13 | 1 | 12 | 0 |
| GRID_AIM_AND_ZEROING_STRUCTURES | 9 | 0 | 2 | 7 |
| OTHER_MULTI_REGION_OR_OBJECT_COUNTING | 8 | 1 | 4 | 3 |
| NESTED_COLOR_OR_CUMULATIVE_ZONES | 3 | 0 | 0 | 3 |
| RADIAL_OR_DIAGNOSTIC_SECTORS | 3 | 0 | 2 | 1 |
| REPEATED_DISCRETE_LABELED_OBJECTS | 3 | 1 | 2 | 0 |

Reusable additions implemented in this pass:

- strict target-specific nested/concentric contour extraction;
- generalized repeated closed-object extraction;
- primary single-region extraction with target-face significance gates;
- upper/central/lower-with-outer spatial topology extraction;
- ordered disjoint spatial-region extraction;
- false-positive guards for tiny marks, logos, line-edge duplicates, page-scale contours, ambiguous groups, and multi-chain topologies.

Every admission remains target-specific. No family geometry or Leg Three template was restored.
