# QT Extractor Capability Cluster Analysis

Unsupported extractor population: **181**
Distinct reusable capability clusters: **9**

Existing proven capabilities: exact-face repeated closed objects (5-Spot, 530, DEA-DOT, SQC-1) and exact prior physical source (B-27E).

| Cluster | Targets | Smallest reusable addition | Representatives |
|---|---:|---|---|
| SILHOUETTE_SPATIAL_ZONES | 60 | outer silhouette plus target-specific upper/central/lower internal boundaries | #45 BT-5H Paper Target, #47 BT-5S Paper Target, #50 CAT-III Paper Target |
| NESTED_SCORING_OR_CONCENTRIC_REGIONS | 53 | nested exact-face contours mapped by semantic priority and containment | #4 B-21E Paper Target, #6 B-21FSX Paper Target, #7 B-21M Paper Target |
| MULTI_FIGURE_AND_RELATIONSHIP_OBJECTS | 29 | separate irregular figures/relationship objects without shared geometry | #42 BT-5-Hostage Paper Target, #60 CR-101 Paper Target, #61 CR-102 Paper Target |
| REPEATED_DISCRETE_DISCRIMINATION_OBJECTS | 13 | repeated closed-object extraction with deterministic reading order | #57 CCSO-Q5 Paper Target, #98 DS-DT-C2 Paper Target, #199 Shootin Aces Paper Target |
| GRID_AIM_AND_ZEROING_STRUCTURES | 9 | line/grid/aim-area extraction with target-specific topology | #41 BT-5-EL DORADO DA Paper Target, #84 DEA-Q-RL Paper Target, #108 DSQ-M4R Paper Target |
| OTHER_MULTI_REGION_OR_OBJECT_COUNTING | 8 | target-specific closed regions/objects with explicit topology | #86 DHS-SQT Paper Target, #104 DSQ-FTU Qual Alt 1, #131 FCSO-IPSC Target |
| NESTED_COLOR_OR_CUMULATIVE_ZONES | 3 | nested colored-boundary extraction with exclusive atomic regions | #175 NM-DPS-Q Paper Target, #176 NM-DPS-Q1 Paper Target, #177 NM-DPS-Q3 Paper Target |
| RADIAL_OR_DIAGNOSTIC_SECTORS | 3 | radial/sector boundary extraction and ordered sector identity | #81 Dart Board Paper Target, #87 DIAG-L Paper Target, #88 DIAG-R Paper Target |
| REPEATED_DISCRETE_LABELED_OBJECTS | 3 | target-specific repeated closed-object extraction and semantic ordering | #119 FBI-CIR Paper Target, #125 FBI-Q-R PLUS Paper Target, #249 USAF-M4-AFQC Paper Target |

The clusters describe software extraction capability only. Every admitted UGO remains target-specific and must pass its own exact-face boundary gate.
